"""Main file for open micro stage"""
from open_micro_stage.calibration_plotter import main
main()